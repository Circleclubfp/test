# Facturas Circle Club — app de escritorio

Esta es la misma app de facturación que la versión web, pero instalable en Mac y Windows.
Los datos se guardan en un **archivo de la computadora** y no en el navegador.

## Dónde quedan los datos

- Por defecto: `Documentos/Facturas Circle Club/facturas.json`
- Todos los días se guarda solo una copia en `respaldos/` (se conservan las últimas 30).
- En **Ajustes → Respaldo → Cambiar carpeta…** el cliente puede elegir una carpeta de
  iCloud Drive, Dropbox, Google Drive u OneDrive. Así los datos también quedan en la nube
  y no se pierden si se daña la computadora.
- Si el archivo principal se daña, la app carga sola el último respaldo.

## Instaladores

| Sistema | Archivo | Cómo se genera |
|---|---|---|
| Windows | `Facturas-Circle-Club-Setup-1.0.0.exe` | Ya generado. También con `npm run dist:win` |
| Mac | `Facturas Circle Club-1.0.0-universal.dmg` | Solo se puede compilar en una Mac, o con GitHub Actions (abajo) |

### Compilar la versión de Mac sin tener que configurar nada

1. Sube esta carpeta a un repositorio privado de GitHub.
2. En la pestaña **Actions**, ejecuta **"Construir instaladores"**.
3. Al terminar (unos 10 minutos), descarga el `.dmg` y el `.exe` desde "Artifacts".

Si prefieres hacerlo en tu Mac: instala Node.js 22 y corre `npm ci && npm run dist:mac`.

## Primera apertura (la app no está firmada)

- **Mac:** al abrirla aparecerá un aviso de que no se puede verificar al desarrollador.
  Hay que ir a *Ajustes del Sistema → Privacidad y seguridad → "Abrir de todos modos"*.
  La app también pedirá permiso para usar la carpeta Documentos.
- **Windows:** SmartScreen mostrará "Windows protegió su PC". Hay que hacer clic en
  *Más información → Ejecutar de todas formas*.

Para que estos avisos no aparezcan (recomendado antes de dársela a los clientes):
- Mac: cuenta de Apple Developer (USD 99/año) para firmar y notarizar la app.
- Windows: certificado de firma de código (según el proveedor, unos USD 200–400/año).

Con esos datos se agregan las credenciales en GitHub y el mismo workflow genera los
instaladores ya firmados.

## Desarrollo

```bash
npm install
npm start          # abre la app
```

`app/index.html` es exactamente el mismo archivo que la versión web.
Cuando detecta que está dentro de la app de escritorio, guarda en disco. Si no, usa el navegador.
