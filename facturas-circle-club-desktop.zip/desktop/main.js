// Facturas Circle Club — app de escritorio (Electron)
// Guarda los datos en un archivo JSON en disco, con respaldo automático diario.
const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

const DATA_FILE = 'facturas.json';
const BACKUP_DIR = 'respaldos';
const KEEP_BACKUPS = 30;

/* ---------------- Configuración y rutas ---------------- */
const configPath = () => path.join(app.getPath('userData'), 'config.json');
function readConfig() {
  try { return JSON.parse(fs.readFileSync(configPath(), 'utf8')); } catch { return {}; }
}
function writeConfig(cfg) {
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify(cfg, null, 2));
}
function dataDir() {
  const cfg = readConfig();
  return cfg.dataDir || path.join(app.getPath('documents'), 'Facturas Circle Club');
}
const dataFile = (dir = dataDir()) => path.join(dir, DATA_FILE);
const today = () => new Date().toISOString().slice(0, 10);

/* ---------------- Lectura / escritura segura ---------------- */
function latestBackup(dir) {
  const bdir = path.join(dir, BACKUP_DIR);
  try {
    const files = fs.readdirSync(bdir).filter(f => /^facturas-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort().reverse();
    return files.length ? path.join(bdir, files[0]) : null;
  } catch { return null; }
}
function readData() {
  const file = dataFile();
  if (!fs.existsSync(file)) return null;
  const raw = fs.readFileSync(file, 'utf8');
  try { JSON.parse(raw); return raw; }
  catch {
    // Archivo dañado: se conserva una copia y se usa el último respaldo
    fs.copyFileSync(file, file + '.danado-' + Date.now());
    const b = latestBackup(dataDir());
    if (b) return fs.readFileSync(b, 'utf8');
    throw new Error('El archivo de datos está dañado y no hay respaldos.');
  }
}
function rotateBackup(dir) {
  const file = dataFile(dir);
  if (!fs.existsSync(file)) return;
  const bdir = path.join(dir, BACKUP_DIR);
  const target = path.join(bdir, `facturas-${today()}.json`);
  if (fs.existsSync(target)) return; // ya hay respaldo de hoy
  fs.mkdirSync(bdir, { recursive: true });
  fs.copyFileSync(file, target);
  const old = fs.readdirSync(bdir).filter(f => /^facturas-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort().reverse().slice(KEEP_BACKUPS);
  old.forEach(f => { try { fs.unlinkSync(path.join(bdir, f)); } catch {} });
}
function writeData(json) {
  JSON.parse(json); // nunca escribir algo inválido
  const dir = dataDir();
  fs.mkdirSync(dir, { recursive: true });
  rotateBackup(dir);
  const file = dataFile(dir), tmp = file + '.tmp';
  fs.writeFileSync(tmp, json);
  try { fs.renameSync(tmp, file); }
  catch { fs.writeFileSync(file, json); try { fs.unlinkSync(tmp); } catch {} } // carpetas en la nube a veces bloquean rename
}

/* ---------------- IPC ---------------- */
ipcMain.on('store:load', e => {
  try { e.returnValue = { data: readData() }; } catch (err) { e.returnValue = { error: err.message }; }
});
ipcMain.on('store:saveSync', (e, json) => {
  try { writeData(json); e.returnValue = { ok: true }; } catch (err) { e.returnValue = { error: err.message }; }
});
ipcMain.handle('store:save', (_e, json) => { writeData(json); return true; });
ipcMain.on('store:dataDir', e => { e.returnValue = dataDir(); });
ipcMain.handle('store:openFolder', () => {
  fs.mkdirSync(dataDir(), { recursive: true });
  return shell.openPath(dataDir());
});
ipcMain.handle('store:changeFolder', async e => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(win, {
    title: 'Elegir carpeta para guardar las facturas',
    buttonLabel: 'Usar esta carpeta',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (r.canceled || !r.filePaths[0]) return false;
  const newDir = r.filePaths[0];
  if (path.resolve(newDir) === path.resolve(dataDir())) return false;
  const current = fs.existsSync(dataFile()) ? fs.readFileSync(dataFile(), 'utf8') : null;
  if (fs.existsSync(dataFile(newDir))) {
    const { response } = await dialog.showMessageBox(win, {
      type: 'question',
      message: 'Esa carpeta ya tiene datos de facturas.',
      detail: '¿Quieres usar los datos que ya están en esa carpeta, o reemplazarlos con los datos actuales?',
      buttons: ['Usar los de la carpeta', 'Reemplazar con los actuales', 'Cancelar'],
      defaultId: 0, cancelId: 2,
    });
    if (response === 2) return false;
    if (response === 1 && current) { rotateBackup(newDir); fs.writeFileSync(dataFile(newDir), current); }
  } else if (current) {
    fs.mkdirSync(newDir, { recursive: true });
    fs.writeFileSync(dataFile(newDir), current);
  }
  writeConfig({ ...readConfig(), dataDir: newDir });
  win.reload();
  return true;
});
ipcMain.handle('pdf:save', async (e, name) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const safe = String(name || 'factura').replace(/[\\/:*?"<>|]/g, '-').slice(0, 100) || 'factura';
  const r = await dialog.showSaveDialog(win, {
    title: 'Guardar factura en PDF',
    defaultPath: path.join(readConfig().pdfDir || app.getPath('documents'), safe + '.pdf'),
    filters: [{ name: 'PDF', extensions: ['pdf'] }],
  });
  if (r.canceled || !r.filePath) return { saved: false };
  const pdf = await e.sender.printToPDF({ printBackground: true, preferCSSPageSize: true });
  fs.writeFileSync(r.filePath, pdf);
  writeConfig({ ...readConfig(), pdfDir: path.dirname(r.filePath) });
  shell.openPath(r.filePath);
  return { saved: true, path: r.filePath };
});

/* ---------------- Ventana ---------------- */
function createWindow() {
  const win = new BrowserWindow({
    width: 1360, height: 900, minWidth: 900, minHeight: 600,
    title: 'Facturas Circle Club',
    backgroundColor: '#f3f4f7',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true,
    },
  });
  // La app no navega fuera de su propia página
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (ev, url) => { if (!url.startsWith('file://')) ev.preventDefault(); });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  return win;
}

const isMac = process.platform === 'darwin';
Menu.setApplicationMenu(Menu.buildFromTemplate([
  ...(isMac ? [{ role: 'appMenu' }] : []),
  { role: 'fileMenu' },
  { role: 'editMenu' },
  { label: 'Ver', submenu: [{ role: 'reload', label: 'Recargar' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }] },
  { role: 'windowMenu' },
]));

// Una sola instancia, para que dos ventanas no se pisen el archivo
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const w = BrowserWindow.getAllWindows()[0];
    if (w) { if (w.isMinimized()) w.restore(); w.focus(); }
  });
  app.whenReady().then(() => {
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => { if (!isMac) app.quit(); });
}
