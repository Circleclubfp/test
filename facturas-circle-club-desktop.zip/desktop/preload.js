// Puente seguro entre la página y el sistema de archivos (solo estas funciones quedan expuestas)
const { contextBridge, ipcRenderer } = require('electron');

function unwrap(r) {
  if (r && r.error) throw new Error(r.error);
  return r;
}

contextBridge.exposeInMainWorld('ccDesktop', {
  load: () => unwrap(ipcRenderer.sendSync('store:load')).data,
  save: json => ipcRenderer.invoke('store:save', json),
  saveSync: json => unwrap(ipcRenderer.sendSync('store:saveSync', json)),
  dataDir: () => ipcRenderer.sendSync('store:dataDir'),
  openDataFolder: () => ipcRenderer.invoke('store:openFolder'),
  changeDataFolder: () => ipcRenderer.invoke('store:changeFolder'),
  savePdf: name => ipcRenderer.invoke('pdf:save', name),
});
